--
-- 转存表中的数据 `thinkox_menu`
--

INSERT INTO `thinkox_menu` (`title`, `pid`, `sort`, `url`, `hide`, `tip`, `group`, `is_dev`) VALUES
('扩展资料查询', 16, 0, 'Admin/User/expandinfo_select', 0, '', '用户管理', 0);