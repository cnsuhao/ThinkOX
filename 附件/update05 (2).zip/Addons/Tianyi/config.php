<?php
return array(
    'expire' => array(
        'title' => '验证码有效期（秒）：',
        'type' => 'text',
        'value' => '120',
    ),

    'clean_interval' => array(
        'title' => '清理数据库间隔（秒）：',
        'type' => 'text',
        'value' => '86400'
    ),

    'app_id' => array(
        'title' => '天翼应用APPID：',
        'type' => 'text',
        'value' => '668228660000034680',
    ),

    'app_secret' => array(
        'title' => '天翼应用密钥：',
        'type' => 'text',
        'value' => '75e30521444f11fb3ec265d3c809e443',
    ),

    'access_token' => array(
        'title' => '天翼访问令牌(Access Token)：',
        'type' => 'text',
        'value' => '4607d0582539012eea100b09e79f136a1397106411735',
    ),

    'refresh_token' => array(
        'title' => '天翼刷新令牌(Refresh Token)：',
        'type' => 'text',
        'value' => '0cbb07946822ca74c70f4288fc50dc531392971135772',
    ),

    'update_access_token_interval' => array(
        'title' => '访问令牌刷新间隔（秒）：',
        'type' => 'text',
        'value' => '1728000',
    ),
);